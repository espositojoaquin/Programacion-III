<?php
use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\usuario;
use App\Models\ORM\cdApi;

include_once __DIR__ . '/../../src/app/modelORM/usuario.php';
include_once __DIR__ . '/../../src/app/modelORM/cdControler.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/usuario', function () {   
         
        $this->post('/', function ($request, $response, $args) {
          // crear nuevo 
          $datos= $request->getParsedBody(); 
           
            $a = new usuario;

            $a->email=$datos['email'];
            $a->clave= crypt( $datos['clave']);
            $a->tipo=$datos['tipo'];
            $a->rol=$datos['rol'];
            $a->foto=$datos['foto'];
            $a->save();
         
          $newResponse = $response->withJson($a, 200);
          return $newResponse;
        });

    });
  }
?>
 