<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
return function (App $app) {
    $container = $app->getContainer();
    $app->group('/Alumno', function () {   

        $this->get('/', function ($request, $response, $args) {
            //return cd::all()->toJson();
    
           $resp= $response->withJson("hola",200);
          return $resp;
            
        });

    });

}
?>