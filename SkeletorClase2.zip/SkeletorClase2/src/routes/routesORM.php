<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\cd;
use App\Models\ORM\cdApi;


include_once __DIR__ . '/../../src/app/modelORM/cd.php';
include_once __DIR__ . '/../../src/app/modelORM/cdControler.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/cdORM', function () {   
         
        $this->get('/', function ($request, $response, $args) {
         echo "llega";
          /* // crear nuevo 
            $a = new cd;
            $a->titel='nuevo';
            $a->save();
            $newResponse = $response->withJson($a, 200);
            // modificar 
            $a = cd::find(7);

            $a->jahr= 1456;
            $a->save();
            $newResponse = $response->withJson($a, 200);

            //eliminar
            $a= cd::destroy(7);
          //return cd::all()->toJson();
         /* $todosLosCds=cd::all();
          $newResponse = $response->withJson($todosLosCds, 200);  */
         // $newResponse = $response->withJson($a, 200);
          //return $newResponse;
        });
    });


     $app->group('/cdORM2', function () {   

        $this->get('/',cdApi::class . ':traerTodos');
   
    });

};