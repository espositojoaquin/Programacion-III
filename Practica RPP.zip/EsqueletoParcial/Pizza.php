<?PHP

//use ___PHPSTORM_HELPERS\object;

require_once './AlumDao.php';
class Pizza
{
 public $id;    
 public $tipo;
 public $cantidad;
 public $sabor;
 public $precio;
 public $foto;
 public $foto2;

 public function __construct($tip,$cant,$sab,$pre,$fot,$fot2)
 {   
     $this->tipo = $tip;
     $this->cantidad=$cant;
     $this->sabor=$sab;
     $this->precio=$pre;
     $this->foto=$fot;
     $this->foto2=$fot2;
    
 }
 public static function validarTipo($tipo)
 {  
    if(strcasecmp($tipo,"molde") == 0 || strcasecmp($tipo,"piedra") == 0){
      return true;
    }
    else
    {
        return false;
    }
 } 
 public static function validarSabor($sabor)
 {  
    if(strcasecmp($sabor,"muzza") == 0 || strcasecmp($sabor,"jamon") == 0 ||strcasecmp($sabor,"especial") == 0){
      return true;
    }else
    {
        return false;
    }
 }  
 
 public static function validarTipoSabor($sabor,$tipo,$op)
 {  
     $datos = Pizza::mostrar();
     $var=false;
     foreach( $datos as $pizza){
        if(strcasecmp($pizza->sabor, $sabor) == 0 && strcasecmp($pizza->tipo, $tipo) == 0){
          
          if($op=="alta")
          {
              $var = true;

          }else
          {
              if($op=="venta")
              {
                  $var = $pizza;
              }
          }
            break;
        }

    }
      
      return $var;
 }  
 
 public static function mostrar(){
    $datos = AlumDao::LeerArchivo("./archivos/pizza.txt");
    $pi = array();
    foreach ($datos as $key => $value) {
     array_push($pi,new Pizza($value->tipo,$value->cantidad,$value->sabor,$value->precio,$value->foto,$value->foto2));
    } 
    return $pi;
}

 public static function idAuto($objeto){
  $datos = Pizza::mostrar();
  $objeto->id=count($datos)+1;
 }

 public static function Guardar($objeto)
 { 
  if(Pizza::validarTipoSabor($objeto->sabor,$objeto->tipo,"alta")==false)
  {   if(Pizza::validarSabor($objeto->sabor) && Pizza::validarTipo($objeto->tipo)){
      Pizza::idAuto($objeto);
      AlumDao::moverImagenes($objeto->foto,$objeto->foto2,$objeto);
      AlumDao::GuardarRegistro("./archivos/pizza.txt",$objeto);
      return "{mensaje:Se guardo con exito}";
      }
      else
      {
          return "{mensaje:sabor o tipo invalido}";
      }
  }
  else
  {
      return "{mensaje: La combinacion ya existe}";
  }
 }

public static function filterTipoSabor($tipo,$sabor){
  $datos = Pizza::mostrar();
   
   $piz="";
   $sab=false;
   $tip=false;
    foreach( $datos as $pizza){
    
       if(strcasecmp($pizza->sabor, $sabor) == 0 && strcasecmp($pizza->tipo, $tipo) == 0){
        
       // $piz=$pizza->cantidad;
        $sab=true;
        $tip=true;
        $piz= "{mensaje: cantidad = ".$pizza->cantidad."}";
        
           break;
       }
       if(strcasecmp($pizza->sabor, $sabor) == 0)
       {
           $sab=true;
       }
       if(strcasecmp($pizza->tipo, $tipo) == 0){
           $tip=true;
       }
   } 
  // echo $sabor;
  if($sab==false && $tip==false)
  {
  $piz= "{mensaje: No existe ni el tipo ni el sabor de pizza especificada}";
  }
  else{
    
    if($sab==false)
    {
        $piz= "{mensaje: el sabor no existe}";
    }
    else{

        if($tip==false){
           $piz=  "{mensaje: El tipo no existe}";
           }
     }
   }
   return $piz; 
 }
 public static function info($array)
 {  
    AlumDao::GuardarRegistro("./archivos/info.log",json_encode($array));
 }

 public static function infoLog($ruta,$metodo,$hora){
    $array=array();
     
     array_push($array,"Ruta: ".$ruta);
     array_push($array,"metodo: ".$metodo);
     array_push($array,"hora: ".$hora); 
     Pizza::info($array);
    
 } 
 public static function descontarStok($obj,$cant)
 {
      $lista = Pizza::mostrar(); 
      $cont=0;
      $array =array();
      foreach($lista as $objeto)
      {  $cont++;
          if($objeto->id == $obj->id)
          {
              $objeto->cantidad -= $cant;
          } 
          $objeto->id=$cont;
          array_push($array,$objeto);
      }

      AlumDao::GuardarLista("./archivos/pizza.txt",$array);
 }
 
 public static function mostrarVen(){
    $datos = AlumDao::LeerArchivo("./archivos/ventas.txt");
   $pi = array();
    foreach ($datos as $value) {
     array_push($pi,$value);
    } 
    return $datos;
}

 public static function idAutoVen(){
  $datos = Pizza::mostrarVen();
  return count($datos)+1;
 }
 public static function Ventas($tip,$sab,$cant)
 {  $array=array();
    $resp = Pizza::validarTipoSabor($sab,$tip,"venta");
    var_dump( $resp->cantidad);
    if($resp!=false)
    {
        if($resp->cantidad >= $cant)
        {
            $id = Pizza::idAutoVen();
            array_push($array,"{id: ".$id,"tipo: ".$tip,"sabor: ".$sab,"cantidad: ".$cant,"precio: ".$resp->precio."}");
            AlumDao::GuardarRegistro("./archivos/ventas.txt",$array);
            Pizza::descontarStok($resp,$cant);
            return "{mensaje: Venta realizada con exito}";
        }
        else
        {
            return "{mensaje: no hay stock disponible o no existe la combinacion solicitada}";
        }
    }
 }

 public static function modificar($datos,$img,$img2,$flag){
 
    $lista = Pizza::mostrar();
    $cont = 0;
  
    $var=false;
   
    foreach( $lista as $objeto ){
        $objeto->id=$cont+1;
        var_dump($objeto->id);
        var_dump( $datos['id']);
        if(strcasecmp($objeto->id, $datos['id']) == 0){
            //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y HUBICACION
            $objeto->tipo = $datos['tipo'];
            $objeto->sabor = $datos['sabor'];
            $objeto->cantidad = $datos['cantidad'];
            $objeto->precio = $datos['precio'];
            $var=true;
            if($flag==true)
            { 
                AlumDao::ModificarImagenes($img,$img2,$objeto);
            }
            break;
        }
    }
 //   var_dump($lista);
    if($var==true)
    {
      AlumDao::GuardarLista('./archivos/pizza.txt', $lista);
      return "{mensaje:modificacion realizadad con exito}";
    }
    echo"$var";
  }

  public static function Eliminar($id)
  {
    $lista = Pizza::mostrar();
    $cont = 0;
  
    $var=false;
   
    foreach( $lista as $objeto ){
        $objeto->id=$cont+1;
        if(strcasecmp($objeto->id, $id) == 0){
            AlumDao::ModificarImagenes($objeto->foto,$objeto->foto2,$objeto);
             $lista.delete($objeto);
         }
    }
}



}
 ?>