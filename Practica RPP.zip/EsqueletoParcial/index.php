<?PHP
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
date_default_timezone_set('America/Argentina/Buenos_Aires');

require './vendor/autoload.php';
require_once './Pizza.php';
$config['displayErrorDetails']=true;
$config['addContentLengthheader']=false;
$app = new \Slim\App(["settings" => $config]);
$app->group('/pizzas', function ()
{  
    $this->post('/cargarPizza', function ($request,$response,$args){
       
        $datos= $request->getParsedBody(); 
        $img = $request->getUploadedFiles();
        $pizza = new Pizza($datos['tipo'],$datos['cantidad'],$datos['sabor'],$datos['precio'],$img["foto"],$img['foto2']);
        echo Pizza::Guardar($pizza);
       });
       
       $this->get('/pizza',function($request,$response,$args){
        $datos=$request->getQueryParams();
        $retorno="{mensaje:Faltan campos}";
        if(isset($datos['sabor']) && isset($datos['tipo']))
        { 
          $retorno =  $response->withJson( Pizza::filterTipoSabor($datos['tipo'],$datos['sabor']));
        //  echo $retorno;
        }
       // Pizza::infoLog("localhost/EsqueletoParcial/pizzas/pizza","get,/pizza",date("H:m:s"));
        return $retorno;
       });
       
       $this->post('/ventas',function($request,$response,$args){
        $datos= $request->getParsedBody(); 
        echo Pizza::Ventas($datos['tipo'],$datos['sabor'],$datos['cantidad']);
       });

       $this->post('/modificar',function($request,$response,$args){
        $datos= $request->getParsedBody(); 
        $img = $request->getUploadedFiles();

        if(isset($img['foto']) && isset($img['foto2'])){
           echo Pizza::modificar($datos,$img['foto'],$img['foto2'],true);
        }
        else
        {
          echo Pizza::modificar($datos,"","",false);
        }
      });
      $this->delete('/eliminar',function($request,$response,$args){
        $datos= $request->getParsedBody();
        if(isset($datos['id'])){

          Pizza::Eliminar($datos['id']);
        }
        else
        {
          echo "mensaje: ingrese un id";
        }
      });

});
$app->run();