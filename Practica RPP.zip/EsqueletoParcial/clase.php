<?PHP
require_once './AlumDao.php';
class Usuario
{ 
 public $legajo;
 
 public function __construct()
 {
    
 }
}
 ?>