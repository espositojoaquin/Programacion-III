<?php
/*
Aplicación Nº 4 (Sumar números)
Confeccionar un programa que sume todos los números enteros desde 1 mientras la suma no
supere a 1000. Mostrar los números sumados y al finalizar el proceso indicar cuantos números
se sumaron.
*/
$suma=0;
$i=0;
$numerosCant=0;
  
    /*for($i=1;$i<1001;$i++)
    {
       // $suma=$suma+$i;
       if($suma>=1000)
       {
           break;
       }
       else
       {
           $suma += $i;
           $numerosCant++;

       }
       
    }*/
    do
    {   
        $i++;
        $suma += $i;
        $numerosCant++;
    } while($suma<1001);

    echo"Suma:$suma <br/>";
    echo"numeros sumados: $numerosCant";



?>