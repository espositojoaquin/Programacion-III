<?php
require_once './Clases/Personas.php';
class Alumno extends Persona
{
   
}
?>