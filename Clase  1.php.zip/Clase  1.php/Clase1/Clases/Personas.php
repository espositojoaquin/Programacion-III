<?php
class Persona
{
 public $nombre;

 public function __construct($nom)
 {
     $this->nombre=$nom;
 }

 public function saludar(){
     echo "Hola";
 }
 
}
?>