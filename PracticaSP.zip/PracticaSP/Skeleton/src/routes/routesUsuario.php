<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\cd;
use App\Models\ORM\cdApi;
use App\Models\ORM\usuario;

include_once __DIR__ . '/../../src/app/modelORM/Usuario.php';
include_once __DIR__ . '/../../src/app/modelORM/cdControler.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/user', function () {   
         
        $this->post('/usuario', function ($request, $response, $args) {
          //return cd::all()->toJson();
          $datos= $request->getParsedBody(); 
           
          $a = new usuario();

          $a->email=$datos['email'];
          $a->clave= crypt( $datos['clave']);
          $a->tipo=$datos['tipo'];
          $a->nombre=$datos['nombre'];
          $a->foto=$datos['foto'];
          $a->idMateria=$datos['idMateria'];
          $a->save();
      
        $newResponse = $response->withJson($a, 200);
        return $newResponse;
        });
    });


     $app->group('/cdORM2', function () {   

        $this->get('/',cdApi::class . ':traerTodos');
   
    });

};