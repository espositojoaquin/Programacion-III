<?php
/*
Aplicación Nº 4 (Sumar números)
Confeccionar un programa que sume todos los números enteros desde 1 mientras la suma no
supere a 1000. Mostrar los números sumados y al finalizar el proceso indicar cuantos números
se sumaron.
*/
$suma=0;
$i=0;
$numerosCant=0;

    while($suma<1001)
    {   
        $i++;
        $suma += $i;
        $numerosCant++;
		if($suma>1001)
		{  
			$numerosCant--;			
			$suma=$suma -$i;
			
			break;
		}
    }

    echo"Suma:$suma <br/>";
    echo"numeros sumados: $numerosCant";
?>