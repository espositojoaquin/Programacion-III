<?php
/*
Aplicación Nº 3 (Sumar dos números II)
Partiendo del ejercicio anterior, modificar la salida por pantalla para que se visualice el valor de
la variable $x , el valor de la variable $y y el resultado final en líneas distintas (recordar que el
salto de línea en HTML es la etiqueta <br/> ).
*/ 

  $num1=5;
  $num2=10;
  $resultado= $num1+$num2;
 /* echo"num 1:$num1 <br/>"; 
  echo"num 2:$num2 <br/>";*/
  
  echo"num 1:$num1".PHP_EOL; 
  echo"num 2:$num2".PHP_EOL;
  echo"Resultado:$resultado";
?>