<?php 
require_once './Clases/Alumno.php'; //si ya esta incluido no lo incluya para evitar error
//$per=new Persona("Juan");
$alu=new Alumno("Pepe");
//$per->saludar();
$alu->saludar();
?>