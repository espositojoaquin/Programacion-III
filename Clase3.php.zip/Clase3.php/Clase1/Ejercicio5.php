<?php
/*require_once './Clases/Alumno.php';
if($_SERVER["REQUEST_METHOD"]=="GET")
{
    if(isset($_GET["nombre"])&& isset($_GET["apellido"]))
    {
        $nombre=$_GET["nombre"];
        $apellido=$_GET["apellido"];
        $al=new Alumno($nombre,$apellido);
    
      echo $al->mostrarJson();

    }

}*/
if($_SERVER["REQUEST_METHOD"]=="POST")
{
    if(isset($_POST["cantidad"])&& !empty($_POST["cantidad"]) )
    {
        $cant=$_POST["cantidad"];
        for($i=0;$i<$cant;$i++)
        {
            $alu= new Alumno("Pepe".$i,"capo".$i);
          //  echo $alu->mostrarJson();
            
        }
      
    }
}

?>

