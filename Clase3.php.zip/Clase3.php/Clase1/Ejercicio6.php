<?php
session_start();
//session_unset();
require_once './Clases/Alumno.php';
require_once './Clases/AlumDao.php';

if(!isset($_SESSION["aux"]))
{
   $_SESSION["aux"]=[];
}
if($_SERVER["REQUEST_METHOD"]=="GET")
{  
    if(isset($_GET["caso"])&&$_GET["caso"]=="alumnos")
    {
        foreach( $_SESSION["aux"] as $alumno)
        {   
            echo $alumno.PHP_EOL;
            echo"<br>";
        }

    }else if(isset($_GET["caso"])&&$_GET["caso"]=="alumno")
    {
        echo  $_SESSION["aux"][0].PHP_EOL;
    }

}
else if($_SERVER["REQUEST_METHOD"]=="POST")
{
    if(isset($_POST["caso"]))
    {  
    if(isset($_POST["nombre"]) && isset($_POST["apellido"]))
    {
            $nombre=$_POST["nombre"];
            $apellido=$_POST["apellido"];
            $al=new Alumno($nombre,$apellido);
            if( $_POST["caso"]=="alta")
            {
                AlumDao::Guardar($al);
                echo "se guardo con existo";
            }
            if( $_POST["caso"]=="baja")
            {
                if(AlumDao::Baja($al))
                {
                    echo "Elemento eliminado";
                }
                else
                {
                    echo "Ocurrio un error o no se enceunta el objeto especificado en la lista";
                }
            }
            else if(isset($_POST["nombreR"]) && isset($_POST["apellidoR"]))
            {
                $nombreR=$_POST["nombreR"];
                $apellidoR=$_POST["apellidoR"];
                $alR=new Alumno($nombreR,$apellidoR);
               if( $_POST["caso"]=="modificacion")
               {   
                    if(AlumDao::Modificar($al,$alR))
                    {
                        echo "Modificacion realizada con exito";
                    }

                   
               }
               else
               {
                   echo "No se ha especificado la operacion";
               }
                    
            }
          // echo $al->mostrarJson();

        }
    }
    else
    {
      echo"ERROR";
    }

}

?>