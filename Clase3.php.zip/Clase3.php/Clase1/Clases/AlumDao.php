<?php
require_once './Clases/Alumno.php';
class AlumDao
{   
    public static function Guardar($alu)
    {   
        array_push($_SESSION["aux"],json_encode($alu));
    }
    public static function Modificar($alu,$alu2)
    { 
       $retorno=false;
       for($i=0;$i<count($_SESSION["aux"]);$i++)
       {
        if($_SESSION["aux"][$i]==json_encode($alu))
        {
            $_SESSION["aux"][$i]=json_encode($alu2);
            $retorno=true;
            echo $_SESSION["aux"][$i];
            break;
        }

       }
       return $retorno;
    }
    public static function Baja($alu)
    {
        $retorno=false;
        $var = json_encode($alu);
        for($i=0;$i<count($_SESSION["aux"]);$i++)
        { 
            if($_SESSION["aux"][$i] == $var)
            {  
                unset($_SESSION["aux"][$i]);
                $retorno=true;
                
                break;
            }
 
        }
        
        return $retorno;
    }

    public static function GuardarRegistro($path,$dato)
    { 
       if(file_exists($path))
       {
           $archivo=fopen($path,'a');
                       
           fwrite($archivo,json_encode($dato).PHP_EOL);  
        
           fclose($archivo);
       }
       else
       {
           echo "No exixte el archivo especificado";
       }             
                
    }
    public static function GuardarLista($path,$lista)
    {
       $archivo=fopen($path,'w');
       foreach ($variable as $lista) {
        fwrite($archivo,json_encode($variable).PHP_EOL);  
       }
       fclose($archivo);
    }

}


?>