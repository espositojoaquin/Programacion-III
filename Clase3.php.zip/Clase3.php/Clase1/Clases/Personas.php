<?php
class Persona
{
 public $nombre;
 public $apellido;

 public function __construct($nom,$ape)
 {
     $this->nombre=$nom;
     $this->apellido=$ape;
 }

 public function saludar(){
     echo "Hola";
 }
 
}
?>