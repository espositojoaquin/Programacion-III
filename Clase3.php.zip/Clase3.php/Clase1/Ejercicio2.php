<?php
  $num1=5;
  $num2=10;
  $resultado= $num1+$num2;

  echo"Resultado:$resultado";
?>