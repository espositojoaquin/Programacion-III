<?php
$nombre="Juan";
$apellido="Perez";
//print("Nombre y Apellido:$nombre $apellido");
echo $nombre." ".$apellido;
//echo"$nombre $apellido"; Es lo mismo que hacer lo de arriba 
?>