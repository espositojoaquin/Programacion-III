<?php
$ar=Fopen("archivo.txt",'a');

fwrite($ar,"Mi primer archivo ".PHP_EOL);  
copy($ar,'C:\Users\alumno\Desktop');

fclose($ar);
?>