<?php
  //  $apellido=$_POST["apellido"];
    //$al= new Alumno($nombre,$apellido);
    $array=array();
    $path=fopen("archivo.txt",'r');
    do{ 
       
        $archivo= trim(fgets($path));
        if($archivo!='')
        array_push($array,json_decode($archivo));

    }while(!feof($path));
    fclose($path); 
 

   var_dump($array);
//copy($ar,'C:\Users\alumno\Desktop'); Investigar

?>