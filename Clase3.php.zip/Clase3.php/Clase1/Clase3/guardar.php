<?php
session_start();
//require '../Clases/Alumno.php';

if(isset($_POST["nombre"]) && isset($_POST["apellido"]))
{
    $pos=$_POST;
  //  $apellido=$_POST["apellido"];
    //$al= new Alumno($nombre,$apellido);
    
    $path=fopen("archivo.txt",'a');
    
    fwrite($path,json_encode($pos).PHP_EOL);  

    fclose($path);
}
//copy($ar,'C:\Users\alumno\Desktop'); Investigar

?>