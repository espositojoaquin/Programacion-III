<?PHP
class Vehiculo
{   
    public $marca;
    public $kilometro;
    public $patente;

    function __construct($mar, $pat, $kilo){
        $this->marca = $mar;
        $this->kilometro = $kilo;
        $this->patente = $pat;
    }
    public function toCSV(){
        $sep = ";";
        return "marca".$this->marca . $sep  . "patente".$this->patente . $sep . "kilometro".$this->kilometro. PHP_EOL;
    }
    public function toString(){
        return  'Marca: ' . $this->marca . ' Patente: ' . $this->patente . ' kilometro: ' . $this->kilometro . PHP_EOL;
    }
   
    public static function leerArchivoDeVehiculos(){
        $rutaArchivo = './archivos/vehiculos.txt';
        $retorno = array(); 
        $archivo = fopen($rutaArchivo, 'r');
        do{
            $vehiculo = trim(fgets($archivo));
            if ($vehiculo != ""){
               // array_push($retorno, new Vehiculo($vehiculo[0], $vehiculo[1],$vehiculo[2]));
               array_push($retorno,json_decode($vehiculo));
            }
        }while(!feof($archivo));
        fclose($archivo); 
        return $retorno;   
    }
    public static function existePatente($patente){
        $listaDeVehiculos = Vehiculo::leerArchivoDeVehiculos();
        foreach($listaDeVehiculos as $vehiculo){
            if(strcasecmp(($vehiculo->patente), $patente) == 0){
                return true;
            }
        }
        return false;
    } 
    public static function cargarVehiculo(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if( isset($_POST['marca']) && !empty($_POST['marca']) &&
                isset($_POST['patente']) && !empty($_POST['patente']) && 
                isset($_POST['kilometro']) && !empty($_POST['kilometro'])){ 
                if(Vehiculo::existePatente($_POST['patente']))  {
                    echo 'Ya existe vehiculo con esa patente';
                }
                else{
                    $vehiculo = new Vehiculo($_POST['marca'], $_POST['patente'], $_POST['kilometro']);
                    Vehiculo::guardarVehiculo($vehiculo);
                }   
            }
            else{
                echo "No se configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }

    public static function guardarVehiculo($vehiculo){
        $rutaArchivo = './archivos/vehiculos.txt';
        $archivo = fopen($rutaArchivo, 'a+');
        fwrite($archivo,json_encode($vehiculo));
        fclose($archivo);
        echo 'Vehiculo guardado con exito!';
    } 

    public static function consultarVehiculo(){
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            if( isset($_GET['parametro']) && !empty($_GET['parametro']) ){
                $parametro = $_GET['parametro'];
                $vehiculos = Vehiculo::leerArchivoDeVehiculos();
                $filtrados = [];
                foreach($vehiculos as $vehiculo){
                    if(Vehiculo::existeParametroEnVehiculo($vehiculo, $parametro)){
                        array_push($filtrados, $vehiculo);
                    }
                }
                if(sizeof($filtrados) > 0){
                    foreach($filtrados as $vehiculo){
                        echo json_encode($vehiculos);
                    }
                }
                else{
                    echo 'No existe ' . $parametro;
                }
            }
            else{
                echo "Debe ingresar un parametro de busqueda.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        }
    } 
    public static function devolverVehiculo($param){
        $parametro = $param;
        $vehiculos = Vehiculo::leerArchivoDeVehiculos();
        $filtrados = [];
        foreach($vehiculos as $vehiculo){
            if(Vehiculo::existeParametroEnVehiculo($vehiculo, $parametro)){
                array_push($filtrados, $vehiculo);
            }
        }
        if(sizeof($filtrados) > 0){
            foreach($filtrados as $vehiculo){
                return json_encode($vehiculos);
            }
        }
        else{
            return 'No existe ' . $parametro;
        }
    }
    
    public static function existeParametroEnVehiculo($vehiculo, $parametro){
        if( strcasecmp($vehiculo->marca, $parametro) == 0 || 
            strcasecmp($vehiculo->patente, $parametro) == 0){
            return true;    
        }
        return false;
    }

} 


?>