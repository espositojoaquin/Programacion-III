<?php 

class Turno{
        private $fecha;
        private $patente;
        private $marca;
        private $precio;
        private $tipo;
        
        function __construct($marca, $tipo, $patente, $precio, $fecha){
            $this->marca = $marca;
            $this->tipo = $tipo;
            $this->patente = $patente;
            $this->precio = $precio;
            $this->fecha = $fecha;
        }

        public function toCSV(){
            $sep = ";";
            return $this->marca . $sep . $this->tipo . $sep . $this->patente . $sep . $this->precio . $sep . $this->fecha . PHP_EOL;
        }
        public function toString(){
            return  'Marca: ' . $this->marca . ' tipo: '.$this->tipo . ' Patente: ' . $this->patente . ' Precio: ' . $this->precio . ' Fecha ' . $this->fecha .PHP_EOL;
        }

        public static function sacarTurno(){
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                if( isset($_POST['patente']) && !empty($_POST['patente']) && 
                    isset($_POST['fecha']) && !empty($_POST['fecha']) &&
                    isset($_POST['precio']) && !empty($_POST['precio'])){ 
                    $vehi=Vehiculo:: devolverVehiculo($_POST['patente']);
                    $ve = json_decode($vehi);
                   
                        $turno = new Turno($ve->marca, $ve->tipo, $_POST['patente'], $_POST['precio'],$_POST['fecha']);
                        Turno::guardarTurno($turno);
                    
                   
                }
                else{
                    echo "No se configuraron todas las variables.";
                }
            }
            else{
                echo "ERROR: Se debe llamar con metodo POST.";
            }
        }
        public static function guardarTurno($turno){
            $rutaArchivo = './archivos/turno.txt';
            $archivo = fopen($rutaArchivo, 'a+');
            fwrite($archivo,json_encode($vehiculo));
            fclose($archivo);
            echo 'turno guardado con exito!';
        } 


        public static function turnos(){
            $turnos = Turno::leerArchivoDeTurnos();
            foreach($turnos as $turno){
                echo json_encode($turno);
            }
        }
        public static function leerArchivoDeTurnos(){
            $rutaArchivo = './archivos/turno.txt';
            $retorno = array(); 
            $archivo = fopen($rutaArchivo, 'r');
            do{
                $turno = trim(fgets($archivo));
                if ($turno != ""){
        
                   array_push($retorno,json_decode($turno));
                }
            }while(!feof($archivo));
            fclose($archivo); 
            return $retorno;   
        }
}
?>