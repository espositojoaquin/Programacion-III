<?php
date_default_timezone_set('America/Argentina/Buenos_Aires');
(require __DIR__ . '/../config/bootstrap.php')->run();
