<?php

use Slim\Routing\RouteCollectorProxy;

use App\Controllers\UsuariosController;
use App\Controllers\MascotasController;
use App\Controllers\TurnosController;
use App\Controllers\TiposController;

use App\Middleware\BeforeMiddleware;
use App\Middleware\ValidateMiddleware;
use App\Middleware\UsuarioBefore;
use App\Middleware\LoginBefore;
use App\Middleware\MidPost;
use App\Middleware\MidGet;
use App\Middleware\MidTipoPost;
use App\Middleware\MidMascotaPost;
use App\Middleware\MidMascotasGet;
use App\Middleware\MidPut;
use App\Middleware\MidDelete;







use function PHPSTORM_META\argumentsSet;

return function ($app) {

    $app->post('/registro', UsuariosController::class . ':add')
    ->add(UsuarioBefore::class)
    ->add(ValidateMiddleware::class);
    
    $app->post('/login', UsuariosController::class . ':login')
    ->add(LoginBefore::class)
    ->add(ValidateMiddleware::class);

    $app->post('/tipo_mascota', TiposController::class . ':addTipo')
    ->add(MidTipoPost::class)
    ->add(ValidateMiddleware::class)
    ->add(BeforeMiddleware::class);

    $app->group('/mascotas', function (RouteCollectorProxy $group) {
    $group->post('[/]', MascotasController::class . ':addMascota')
    ->add(MidMascotaPost::class)
    ->add(ValidateMiddleware::class);

    })->add(BeforeMiddleware::class);

    $app->group('/turnos', function (RouteCollectorProxy $group) {
       
        $group->post('/mascotas', TurnosController::class . ':addTurno')
        ->add(ValidateMiddleware::class)
        ->add(MidPost::class);
        $group->get('/{id_usuarios}',TurnosController::class. ':getTurnos')
        ->add(MidGet::class);
        $group->get('/mascotas/{id_mascota}', MascotasController::class . ':getMascotas')
        ->add(MidMascotasGet::class);

        $group->put('/modificar/{id_veterinario}/{id_turno}', TurnosController::class . ':putTurnos')
        ->add(MidPut::class);

        $group->delete('/eliminar/{turno_id}', TurnosController::class . ':deleteTurnos')
        ->add(MidDelete::class);
        
    })->add(BeforeMiddleware::class);
   
   

 

};