<?php 
namespace App\Models;
class Mascota extends \Illuminate\Database\Eloquent\Model{

    public $timestamps = false;
    /*public function Mascota()
    {
        return $this->hasOne('App\Models\Mascota','id','id');
    } 
    /*public static function inscriptos ($array)
    { 
        $retorno = [];
      foreach($array as $item)
      {
          $objeto = Mascota::where("id",$item->alumno_id)->select('email','nombre','legajo')->get();
          array_push($retorno,$objeto);
      }

      return $retorno;
    } */

    public static function Exist($nombre,$dato,$nombre2 = null,$dato2 = null)
    {   $retorno =false; 
       
        if($nombre2 == null && $dato2 == null)
        {
            $mat = Mascota::where($nombre,$dato)->get();
            
            if($mat != "[]")
            {
                $retorno = true;
            }
        }
        else
        {
            if($nombre2 != null && $dato2 != null)
            {
                $mat = Mascota::where($nombre,$dato)
                ->where($nombre2,$dato2)
                ->get();
                if($mat != "[]")
                {   
                    $retorno = true;
                }
            }
        }

        return $retorno;
    }
}