<?php
namespace App\Models;
class Tipo_mascota extends \Illuminate\Database\Eloquent\Model{

    public $timestamps = false;

    public static function Exist($nombre,$dato,$nombre2 = null,$dato2 = null)
    {   $retorno =false; 
       
        if($nombre2 == null && $dato2 == null)
        {
            $mat = Tipo_mascota::where($nombre,$dato)->get();
            
            if($mat != "[]")
            {
                $retorno = true;
            }
        }
        else
        {
            if($nombre2 != null && $dato2 != null)
            {
                $mat = Tipo_mascota::where($nombre,$dato)
                ->where($nombre2,$dato2)
                ->get();
                if($mat != "[]")
                {   
                    $retorno = true;
                }
            }
        }

        return $retorno;
    }
}