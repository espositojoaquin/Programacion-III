<?php 
namespace App\Models;
class Turnos extends \Illuminate\Database\Eloquent\Model{

    public $timestamps = false;

  /*  public function User()
    {
        return $this->hasOne('App\Models\User','id','profesor_id');
    } */
       
    /*
    / Valida que exista un elemento determinado en la Base de datos.
    / retorna true si existe y false sino
    */
    public static function Exist($nombre,$dato,$nombre2 = null,$dato2 = null)
    {   $retorno =false; 
        if($nombre2 == null && $dato2 == null)
        {
            $mat = Turnos::where($nombre,$dato)->get();
            
            if($mat != "[]")
            {
                $retorno = true;
            }
        }
        else
        {
            if($nombre2 != null && $dato2 != null)
            {
                $mat = Turnos::where($nombre,$dato)
                ->where($nombre2,$dato2)
                ->get();
                if($mat != "[]")
                {
                    $retorno = true;
                }
            }
        }

        return $retorno;
    }
}