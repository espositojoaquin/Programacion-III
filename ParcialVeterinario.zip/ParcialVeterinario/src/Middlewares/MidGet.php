<?php
namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use Psr\Http\Message\ResponseInterface as Response;

use Slim\Psr7\Response;
use App\Utils\Funciones;
use App\Models\Turno;
use App\Models\Usuario;
use App\Models\Mascota;
use App\Models\Turnos;
use DateTime;
use stdClass;

class MidGet
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */
    public function __invoke(Request $request, RequestHandler $handler): Response
    {      
     
       $dato = Funciones::obtenerDatoUlt($request->getUri()->getPath());
       $anteUlt = Funciones::obtenerDatoAnte($request->getUri()->getPath());
       
       if(Funciones::validacionTipoToken("veterinario","tipo"))
       {   
            if(Usuario::Exist("id",$dato,"tipo","veterinario"))
            {
                //2702040929964503602
                $retorno = [];
                $fecha_actual = date("Y-m-d");
                $tur = Turnos::where("veterinario_id",$dato)
                ->where("fecha",">",date("Y-m-d",strtotime($fecha_actual."- 0 days")))
                ->where("fecha","<",date("Y-m-d",strtotime($fecha_actual."+ 1 days")))
                ->get();

                if($tur != "[]")
                {
                    
                   foreach($tur as $item)
                   {     
                       //el nombre de la mascota, la hora, fecha, el nombre del dueño y la edad de la mascota.
                        
                         $obj = new stdClass();
                         $obj->mascota = (Mascota::where('id',$item->mascota_id)->select('nombre')->get())[0]->nombre;
                         $fechaNacimiento = (Mascota::where('id',$item->mascota_id)->select('fecha_nacimiento')->get())[0]->fecha_nacimiento;
                         $obj->edad = Funciones::date_interval(date("Y-m-d"),$fechaNacimiento);
                         $obj->fechaYhora = $item->fecha;
                         $obj->nombre_Veterinario = (Usuario::where('id',$item->veterinario_id)->select('usuario')->get())[0]->usuario;
        
                         array_push($retorno,$obj);
                   }
                   $request= $request->withAttribute("turnos",$retorno);
                   $resp = new Response();
                   $response = $handler->handle($request);
                   $existingContent = (string) $response->getBody();
                   $resp->getBody()->write($existingContent);   
                   return $resp;

                }
                else
                {
                    $resp = new Response();
                    $resp->getBody()->write(json_encode(array("Error" =>"No tiene turnos Asignados en el dia de la fecha")));
                    return $resp; 
    
                }
            }
            else
            {
                $resp = new Response();
                $resp->getBody()->write(json_encode(array("Error" =>"Veterinario Inexistente")));
                return $resp; 

            }
       }
       else
       {
           if(Funciones::validacionTipoToken("cliente","tipo"))
           { 
            if(Usuario::Exist("id",$dato,"tipo","cliente"))
            {
                $turnos = Mascota::join("turnos","turnos.mascota_id","=","mascotas.id")
                ->join("usuarios","usuarios.id","=","mascotas.cliente_id")
                ->where("mascotas.cliente_id",$dato)
                ->select('mascotas.nombre','turnos.fecha','usuarios.usuario')
                ->get();
                if($turnos!= "[]")
                {
                    foreach($turnos as $item)
                    {     
                        $time = new DateTime($item->fecha);
                        $time->setTime(0,0);
                        $fecha = new DateTime(date("Y-m-d"));
                        if($time > $fecha) 
                        {  
                            $item->nombre = strtoupper($item->nombre);
                            $item->fecha = strtoupper($item->fecha);
                            $item->usuario = strtoupper($item->usuario);
                        }
                        
                    }
                    $request= $request->withAttribute("turnos",$turnos);
                    $resp = new Response();
                    $response = $handler->handle($request);
                    $existingContent = (string) $response->getBody();
                    $resp->getBody()->write($existingContent);   
                    return $resp;

                }
                else
                {
                    $resp = new Response();
                    $resp->getBody()->write(json_encode(array("Error" =>"No tiene turnos Asignados")));
                    return $resp;  
                }

            }
            else
            {
                $resp = new Response();
                $resp->getBody()->write(json_encode(array("Error" =>"Cliente Inexistente")));
                return $resp;  
            }
    
           }
           else
           {   
            $resp = new Response();
            $resp->getBody()->write(json_encode(array("Error" =>"Solo veterinario o Cliente")));
            return $resp; 
           }

       }
    
        
    }
}
