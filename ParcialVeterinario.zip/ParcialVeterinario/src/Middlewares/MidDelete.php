<?php
namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use Psr\Http\Message\ResponseInterface as Response;

use Slim\Psr7\Response;
use App\Utils\Funciones;


use App\Models\Usuario;
use App\Models\Turnos;
use App\Models\Mascota;
use App\Models\Model3;
use stdClass;

class MidDelete
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */
    public function __invoke(Request $request, RequestHandler $handler): Response
    {      
     
       $dato = Funciones::obtenerDatoUlt($request->getUri()->getPath());
      // $anteUlt = Funciones::obtenerDatoAnte($request->getUri()->getPath());
       
       
           if(Funciones::validacionTipoToken("admin","tipo"))
           {
                     $obj = Turnos::Exist("id",$dato);
                   
                     if($obj)
                     {   
                         
                            $resp = new Response();
                            $response = $handler->handle($request);
                            $existingContent = (string) $response->getBody();
                            $resp->getBody()->write($existingContent);   
                            return $resp;
                            
    
                     }
                     else
                     {
                        $resp = new Response();
                        $resp->getBody()->write(json_encode(array("Error" =>" Turno inexistente")));
                        return $resp;
                     }
                   
                 
              
           }
           else
           {
                $resp = new Response();
                $resp->getBody()->write(json_encode(array("Error" =>"Solo el administrador puede borrar un turno")));
                return $resp;
           }

       
    
        
    }
}