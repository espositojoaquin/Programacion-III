<?php
namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use Psr\Http\Message\ResponseInterface as Response;

use Slim\Psr7\Response;
use App\Utils\Funciones;
use App\Models\Obj;
use App\Models\Turnos;
use App\Models\Usuario;
use App\Models\Mascota;
use DateTime;
use DateTimeZone;

class MidPost
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */
    public function __invoke(Request $request, RequestHandler $handler): Response
    {      
          $arrDatos = $request->getParsedBody();
          $Obj = new Turnos();
          $Obj->veterinario_id = $arrDatos['veterinario_id']??"0";
          $Obj->mascota_id = $arrDatos['mascota_id']??"0";
          $Obj->fecha = $arrDatos['fecha']??"0";
          $hora = $arrDatos['hora']??"0";
          
          if($hora != "0" && $Obj->veterinario_id != "0" && $Obj->mascota_id != "0" && $Obj->fecha != "0") 
          {
                if(Funciones::validacionTipoToken("cliente","tipo"))
                { 
                   if(Usuario::Exist("id",$Obj->veterinario_id,"tipo","veterinario"))
                   {
                    if(Mascota::Exist("id",$Obj->mascota_id))
                    {
                        if(Funciones::validarHora($hora,9,17) === true)
                        {    
                             
                            $Obj->fecha = Funciones::Fecha_hora($Obj->fecha,$hora);
                            
                            $ext1 = Turnos::Exist("fecha",$Obj->fecha,"veterinario_id",$Obj->veterinario_id);
                            if(!$ext1)
                            {   
                                $ext2 = Turnos::where("fecha",$Obj->fecha)->get();
    
                                if(count($ext2)<2)
                                {   
                                    
                                    $request = $request->withAttribute("turno",$Obj);
                                    $resp = new Response();
                                    $response = $handler->handle($request);
                                    $existingContent = (string) $response->getBody();
                                    $resp->getBody()->write($existingContent);   
                                    return $resp;
                                }
                                else
                                {
                                    $resp = new Response();
                                    $resp->getBody()->write(json_encode(array("Error" =>"No hay turnos disponibles en esta fecha y hora")));
                                    return $resp;   
                                }
                               
        
                            }
                            else
                            {
                              $resp = new Response();
                              $resp->getBody()->write(json_encode(array("Error" =>"Ya hay un turno solicitado en esta fecha y hora con este veterinario")));
                               return $resp;
                            }
    
                        }
                        else
                        {
                            $resp = new Response();
                              $resp->getBody()->write(json_encode(array("Error" =>Funciones::validarHora($hora,9,17))));
                               return $resp;
                        }
 
                    } 
                    else
                    {  
                        $resp = new Response();
                         $resp->getBody()->write(json_encode(array("Error" =>"Mascota inexsistente")));
                         return $resp;
                    }

                   }
                   else
                   {
                    $resp = new Response();
                    $resp->getBody()->write(json_encode(array("Error" =>"Veterinario inexsistente")));
                    return $resp;
                   }
                }
                else
                {
                    $resp = new Response();
                    $resp->getBody()->write(json_encode(array("Error" =>"solo los clientes puede solicitar un turno")));
                    return $resp;
                }
          }
          else
          {
            $resp = new Response();
            $resp->getBody()->write(json_encode(array("Error" =>"Datos insuficientes")));
            return $resp;
          }

        
    }
}