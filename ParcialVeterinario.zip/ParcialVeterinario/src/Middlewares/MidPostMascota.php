<?php
namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use Psr\Http\Message\ResponseInterface as Response;

use Slim\Psr7\Response;
use App\Models\Mascota;
use App\Models\Usuario;
use App\Utils\Funciones;
use App\Models\Obj;
use App\Models\Tipo_mascota;
use Date;
use DateTime;
use Illuminate\Support\Facades\Date as FacadesDate;

class MidMascotaPost
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */
    public function __invoke(Request $request, RequestHandler $handler): Response
    {      
          $arrDatos = $request->getParsedBody();
          $Obj = new Mascota();
          $Obj->nombre = $arrDatos['nombre']??"0";
          $Obj->fecha_nacimiento = $arrDatos['fecha_nacimiento']??"0";
          $Obj->cliente_id = $arrDatos['cliente_id']??"0";
          $Obj->tipo_mascota_id = $arrDatos['tipo_mascota_id']??"0";
          
          if($Obj->nombre != "0" && $Obj->fecha_nacimiento != "0" && $Obj->cliente_id != "0" && $Obj->tipo_mascota_id ) 
          {    
                    $ext1 = Usuario::Exist("id",$Obj->cliente_id,"tipo","cliente");
                    if($ext1)
                    {   
                        $ext2 = Tipo_mascota::Exist("id",$Obj->tipo_mascota_id);
                        if($ext2)
                        {    
                            $Obj->fecha_nacimiento = Funciones::Fecha($Obj->fecha_nacimiento);
                            $request = $request->withAttribute("mascota",$Obj);
                            $resp = new Response();
                            $response = $handler->handle($request);
                            $existingContent = (string) $response->getBody();
                            $resp->getBody()->write($existingContent); 
                            return $resp;
                        }
                        else
                        {
                            $resp = new Response();
                            $resp->getBody()->write(json_encode(array("Error" =>"Tipo de mascota inexistente")));
                            return $resp;   
                        }
                        // echo json_encode($Obj);

                    }
                    else
                    {
                      $resp = new Response();
                      $resp->getBody()->write(json_encode(array("Error" =>"Cliente inexistente")));
                       return $resp;
                    }
                
                
          }
          else
          {
            $resp = new Response();
            $resp->getBody()->write(json_encode(array("Error" =>"Datos insuficientes")));
            return $resp;
          }

        
    }
}