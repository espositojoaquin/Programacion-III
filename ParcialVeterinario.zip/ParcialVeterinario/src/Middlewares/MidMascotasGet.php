<?php
namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use Psr\Http\Message\ResponseInterface as Response;

use Slim\Psr7\Response;
use App\Utils\Funciones;
use App\Models\Turno;
use App\Models\Usuario;
use App\Models\Mascota;
use App\Models\Turnos;
use DateTime;
use stdClass;

class MidMascotasGet
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */
    public function __invoke(Request $request, RequestHandler $handler): Response
    {      
     
       $dato = Funciones::obtenerDatoUlt($request->getUri()->getPath());
       
         
            if(Mascota::Exist("id",$dato))
            {
                //2702040929964503602
                $retorno = new stdClass();

                $mascota = Mascota::find($dato);
                $turnos = Turnos::join("usuarios","usuarios.id","=","turnos.veterinario_id")
                ->where("mascota_id",$dato)
                ->select('turnos.fecha','usuarios.usuario')
                ->get();   

                if($turnos != "[]")
                {
                    //echo json_encode($tur);
                    /*Todos los usuarios deben poder ver el historial de atención de una
                     mascota con el nombre de la mascota, su edad, la fecha de todas las visitas que hizo al centro veterinario
                     y el nombre del veterinario.*/
                      $retorno->nombre_Mascota = $mascota->nombre;
                      $retorno->edad = Funciones::date_interval(date("Y-m-d"),$mascota->fecha_nacimiento);
                      $retorno->turnos = $turnos; 
                        
                   $request= $request->withAttribute("mascotas",$retorno);
                   $resp = new Response();
                   $response = $handler->handle($request);
                   $existingContent = (string) $response->getBody();
                   $resp->getBody()->write($existingContent);   
                   return $resp;

                }
                else
                {
                    $resp = new Response();
                    $resp->getBody()->write(json_encode(array("Error" =>"No tiene turnos Asignados ")));
                    return $resp; 
    
                }
            }
            else
            {
                $resp = new Response();
                $resp->getBody()->write(json_encode(array("Error" =>"Mascota Inexistente")));
                return $resp; 

            }
       
       
       
        
    }
}
