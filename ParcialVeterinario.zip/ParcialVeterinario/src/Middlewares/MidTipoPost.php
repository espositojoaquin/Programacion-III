<?php
namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use Psr\Http\Message\ResponseInterface as Response;

use Slim\Psr7\Response;
use App\Utils\Funciones;
use App\Models\Tipo_mascota;
use App\Models\Usuario;


class MidTipoPost
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */
    public function __invoke(Request $request, RequestHandler $handler): Response
    {      
          $arrDatos = $request->getParsedBody();
          $Obj = new Tipo_mascota();
          $Obj->tipo = $arrDatos['tipo']??"0";
          
          
          if($Obj->tipo != "0" ) 
          {
                if(Funciones::validacionTipoToken("admin","tipo"))
                {   
                   
                    $ext1 =Tipo_mascota::Exist("tipo",$Obj->tipo);
                    if(!$ext1)
                    {   
                       
                            $request = $request->withAttribute("tipo",$Obj);
                            $resp = new Response();
                            $response = $handler->handle($request);
                            $existingContent = (string) $response->getBody();
                            $resp->getBody()->write($existingContent);   
                            return $resp;
                       
                       

                    }
                    else
                    {
                      $resp = new Response();
                      $resp->getBody()->write(json_encode(array("Error" =>"Tipo de mascota existente")));
                       return $resp;
                    }
                }
                else
                {
                    $resp = new Response();
                    $resp->getBody()->write(json_encode(array("Error" =>"Se requieren permisos de administrador")));
                    return $resp;
                }
          }
          else
          {
            $resp = new Response();
            $resp->getBody()->write(json_encode(array("Error" =>"Datos insuficientes")));
            return $resp;
          }

        
    }
}