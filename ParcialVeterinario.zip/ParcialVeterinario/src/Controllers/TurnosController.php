<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Mascota;
use App\Models\Turnos;

class TurnosController{
 
    public function addTurno(Request $request, Response $response, $args)
    {   
       
        $rta ="";
       
        $tipo = $request->getAttribute("turno");
        $rta = json_encode(array("ok" => $tipo->save()));

        $response->getBody()->write($rta);

        return $response;
    }
    
    public function getTurnos(Request $request, Response $response, $args)
    {   
       
        $objeto = $request->getAttribute("turnos");
        $rta = json_encode(array("ok" => $objeto)); 
        $response->getBody()->write($rta);

        return $response;
    }
    public function putTurnos(Request $request, Response $response, $args)
    {   
        
        Turnos::where("id",$args["id_turno"])->update(['veterinario_id' => $args["id_veterinario"] ]);
        $rta = json_encode(array("ok" => "Veterinario actualizado con exito")); 
        $response->getBody()->write($rta);

        return $response;
    }
    public function deleteTurnos(Request $request, Response $response, $args)
    {
        $tur = Turnos::find($args["turno_id"]);
        $tur->delete();
        //Turnos::destroy($args["turnos_id"]);
        $rta = json_encode(array("ok" => "Turno con exito")); 
        $response->getBody()->write($rta);
        return $response;
    }




}