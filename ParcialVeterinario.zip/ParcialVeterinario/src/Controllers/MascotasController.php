<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Mascota;




class MascotasController{
 
    public function addMascota(Request $request, Response $response, $args)
    {   
       
        $rta ="";
       
        $tipo = $request->getAttribute("mascota");
        $rta = json_encode(array("ok" => $tipo->save()));

        $response->getBody()->write($rta);

        return $response;
    }
  
    public function getMascotas(Request $request, Response $response, $args)
    {   
       
        $objeto = $request->getAttribute("mascotas");
        $rta = json_encode(array("ok" => $objeto)); 
        $response->getBody()->write($rta);

        return $response;
    }
  
}