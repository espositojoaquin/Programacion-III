<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Mascota;


class TiposController{
  
    public function addTipo(Request $request, Response $response, $args)
    {   
       
        $rta ="";
       
        $tipo = $request->getAttribute("tipo");
        $rta = json_encode(array("ok" => $tipo->save()));

        $response->getBody()->write($rta);

        return $response;
    }


}