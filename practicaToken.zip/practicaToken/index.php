<?PHP
 use \Psr\Http\Message\ServerRequestInterface as Request;
 use \Psr\Http\Message\ResponseInterface as Response;
 use\Firebase\JWT\JWT;

 require './vendor/autoload.php';

 $config['displayErrorDetails']=true;
 $config['addContentLengthheader']=false;
 $app = new \Slim\App(["settings" => $config]);
 $app->group('/auth', function ()
 {  
     $this->post('/login', function ($request,$response,$args){
        
         $datos = $request->getParsedBody(); 
         $key = "2302";
         $token=array(
             "iss" => "http://example.org",
             "aud"=> "http://example.org",
             "ist" => 1356999524,
             "nbf"=> 1357000000,
             "user" => $datos["user"]

         );
         $jwt = JWT::encode($token, $key);
         $newResponse = $response->withJson($jwt, 200);
         return $newResponse;
       
        });
        // chequear que exista el token que sea, valido y que no este vencido.
        $this->get('/token',function($request,$response,$args){
         $datos=$request->getQueryParams();
         $key="2302";
         $jwt = $request->getHeader("token")[0];
     

             $decode = JWT::decode($jwt,$key,array('HS256'));
         
       
           
         
         $newResponse = $response->withJson($decode, 200);
        return $newResponse;     
        });
 
 });
 $app->run();
?>