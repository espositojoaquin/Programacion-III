<?PHP
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
require './vendor/autoload.php';
require_once './clase.php';
$config['displayErrorDetails']=true;
$config['addContentLengthheader']=false;

$app = new \Slim\App(["settings" => $config]);
$app->group('/usuarios', function ()
{  
    
    $this->post('/cargarUsuario', function ($request,$response,$args){
       
      /*  $datos= $request->getParsedBody(); 
        $img = $request->getUploadedFiles();
        $usuario = new Usuario($datos['legajo'],$datos['email'],$datos['nombre'],$datos['clave'],$img["foto"],$img['foto2']);
        echo Usuario::Guardar($usuario);*/
      echo "anda piola";
       });

});
$app->run();