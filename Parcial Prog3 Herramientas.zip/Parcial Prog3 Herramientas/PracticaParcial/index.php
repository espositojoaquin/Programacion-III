<?PHP
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
require './vendor/autoload.php';
require_once './Usuario.php';
$config['displayErrorDetails']=true;
$config['addContentLengthheader']=false;

$app = new \Slim\App(["settings" => $config]);
$app->group('/usuarios', function ()
{  
    
    $this->post('/cargarUsuario', function ($request,$response,$args){
       
        $datos= $request->getParsedBody(); 
        $img = $request->getUploadedFiles();
        $usuario = new Usuario($datos['legajo'],$datos['email'],$datos['nombre'],$datos['clave'],$img["foto"],$img['foto2']);
        echo Usuario::Guardar($usuario);

       });
       $this->get('/login', function($request,$response,$args){
       $datos=$request->getQueryParams();
       $retorno="{mensaje:Faltan campos}";
       if(isset($datos['legajo']) && isset($datos['clave']))
       { 
           if(($datos['legajo']!="")&&($datos['clave'])!="")
           {
               $retorno =  $response->withJson(Usuario::login($datos['legajo'],$datos['clave']));

           }
           else
           {
               json_encode("{mensaje: Verifique que algun campo no este en Blanco}");
           }
          
       }
       $array=array();
     
      /* $hora.=":";
       $hora.= getdate("minutes");
       $hora.=":";
       $hora.=getdate("seconds");*/
       array_push($array,"Caso:cargarUsuario");
       array_push($array,"hora"." ".date("H:m:s")); 
       array_push($array,"ip:".$_SERVER['REMOTE_ADDR']);
       Usuario::infolog($array);
       return $retorno;
       });

       $this->post('/modificarUsuario', function($request,$response,$args){
        $img = $request->getUploadedFiles(); 
        $datos= $request->getParsedBody();
        Usuario::modificar($datos,$img['foto'],$img['foto2']); 
           
    
        //AlumDao::moverImagen();
  
        });

});

$app->run();