<?PHP
require_once './AlumDao.php';
class Usuario
{ 
 public $legajo;
 public $email;
 public $nombre;
 public $clave;
 public $foto;
 public $foto2;

 public function __construct($leg,$em,$nom,$cla,$fot,$fot2)
 {
     $this->legajo = $leg;
     $this->email  = $em;
     $this->nombre = $nom;
     $this->clave  = $cla;
     $this->foto   = $fot;
     $this->foto2  = $fot2;
 }

 function toJSON(){
  return json_encode($this);            
 }
 
 public static function mostrar(){
     $datos = AlumDao::LeerArchivo("./archivos/usuarios.txt");
     $usuarios = array();
     foreach ($datos as $key => $value) {
      array_push($usuarios,new Usuario($value->legajo,$value->email,$value->nombre,$value->clave,$value->foto,$value->foto2));
     }
     return $usuarios;
 }
 public static function validarlegajo($legajo){
    $usuarios = Usuario::mostrar();
    foreach($usuarios as $item){
        if(strcasecmp($item->legajo, $legajo) == 0)
            return true;
    }
    return false;
}
 public static function Guardar($objeto)
 { 
  if(Usuario::validarlegajo($objeto->legajo)==false)
  {
      AlumDao::moverImagenes($objeto->foto,$objeto->foto2,$objeto);
      AlumDao::GuardarRegistro("./archivos/usuarios.txt",$objeto);
      return "{mensaje:Se guardo con exito}";
  }
  else
  {
      return "{mensaje:El legajo ingresado ya existe}";
  }
 }
 public static function login($legajo,$clave){
    $vehiculos= Usuario::mostrar();
    $login = array();
    foreach($vehiculos as $value)
    { 
      if(strcasecmp($value->legajo,$legajo) == 0 && strcasecmp($value->clave,$clave) == 0){
         array_push($login,$value);
      }
      else if(strcasecmp($value->legajo,$legajo) != 0 && strcasecmp($value->clave,$clave) == 0){
          $login="{mensaje:Legajo Incorrecto}";
         // json_encode($login);
      } 
      else if(strcasecmp($value->legajo,$legajo) == 0 && strcasecmp($value->clave,$clave) !=0){
        $login="{mensaje:clave incorrecto}";
      }
      else
      {
          $login="{mensaje:legajo y contrasenia incorrecta}";
      }
    }
    json_encode($login);
    return $login;
 }

 public static function infolog($array)
 {
    AlumDao::GuardarRegistro("./archivos/info.log",$array);
 }

 public static function modificar($datos,$img,$img2){
    // var_dump($datos);
    // var_dump($img);
    $usuarios = Usuario::mostrar();
  
    $var=false;
  
    foreach( $usuarios as $vehiculo ){
        if(strcasecmp($vehiculo->legajo, $datos['legajo']) == 0){
            //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y HUBICACION
           AlumDao::ModificarImagenes($img,$img2,$vehiculo);
            $vehiculo->nombre = $datos['nombre'];
            $vehiculo->email = $datos['email'];
            $vehiculo->calve = $datos['clave'];
            $var=true;
            break;
        }
    }
    if($var==true)
    {
      AlumDao::guardarTodos('./archivos/usuarios.txt', $usuarios);
    }
    echo"$var";
  }






}
?>