<?PHP
class Turno
{
 public $fecha;
 public $tipoDeServicio;   
 public $marca;
 public $modelo;
 public $patente;
 public $precio;

 public function __construct($marc,$mod,$pat,$prec,$fech,$tds)
 {   
     $this->fecha=$fech;
     $this->tipoDeServicio=$tds;
     $this->marca=$marc;
     $this->modelo=$mod;
     $this->patente=$pat;
     $this->precio=$prec;
 } 

 public function Json()
 {
     return json_encode($this);
 }
 
 
 
}
?>