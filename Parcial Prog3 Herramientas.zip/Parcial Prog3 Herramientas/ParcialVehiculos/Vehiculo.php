<?PHP
require_once './AlumDao.php';
class Vehiculo
{ 
 public $marca;
 public $modelo;
 public $patente;
 public $precio;
 public $foto;

 
 
 public function __construct($marc,$mod,$pat,$prec,$fot)
 {
     $this->marca=$marc;
     $this->modelo=$mod;
     $this->patente=$pat;
     $this->precio=$prec;
     $this->foto= $fot;
 }
 function toJSON(){
  return json_encode($this);            
}
 public static function Guardar($objeto)
 { 
  $img=$objeto->foto;
  $origen = $img->file;
  $nombreOriginal =$img->getClientFilename();
  $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
  $destinoFoto = "./imagenes/".$objeto->patente.".".$ext;
  move_uploaded_file($origen, $destinoFoto);
  $objeto->foto=$destinoFoto;

   AlumDao::GuardarRegistro("./archivos/vehiculos.txt",$objeto);
 }
 public static function mostrar(){
  $datos = AlumDao::LeerArchivo("./archivos/vehiculos.txt");
  $vehiculos = array();
  foreach ($datos as $key => $value) {
   array_push($vehiculos,new Vehiculo($value->marca,$value->modelo,$value->patente,$value->precio,$value->foto));
  }
  return $vehiculos;
 }
 public static function mostarTablaVe(){
  $vehiculos = Vehiculo::mostrar();
 
    $datos = "<!DOCTYPE html>
                <html lang='en'>
                <head>
                    <title>Vehiculos</title>
                </head>
                <style>
                    table{
                        width: 100%;
                        border-collapse: collapse; /*sin bordes entre los elementos internos*/
                    }
                
                    thead{
                        font-size: 18px;
                        font-weight: bold;
                    }
                    th, td{
                        text-align: center;
                        padding: 10px;
                    }
                
                    tr:nth-child(even){
                        background-color: #f2f2f2;
                    }
                
                    th{
                        background:#252932;
                        color: #fff;
                        font: bold;
                    }
                
                    img{
                        height: 80px;
                        width: 80px;
                        border-radius: 100%;
                    }
                </style>
                <body>
                    <table>
                        <thead>
                            <tr>
                                <td>Marca</td>
                                <td>Modelo</td>
                                <td>Patente</td>
                                <td>Precio</td>
                                <td>Foto</td>
                            </tr>
                        </thead>
                        <tbody>";
 
    foreach($vehiculos as $item){
        $datos .= "<tr>
                        <td>" .$item->marca. "</td>
                        <td>" .$item->modelo. "</td>
                        <td>" .$item->patente. "</td>
                        <td>" .$item->precio. "</td>
                        <td><img src='." .$item->foto. "'/></td>
                </tr>";
    }   
    $datos .= " </tbody>
            </table>
        </body>
        </html>";
 //   echo $datos;
 // $tabla="<table border='1' ><th>Marca</th><th>Modelo</th><th>Patente</th><th>Precio</th><th>Imagen</th>";

    //$tabla.="<tbody><tr><td>$value->marca</td><td>$value->modelo</td><td>$value->patente</td><td>$value->precio</td><td background='$value->foto ' style='height:20vh;width:20vh;'><img src='.$value->foto'  height='50' width='500'  alt='500' /></td></tr>";
  
  /*return "<table border='1'><th>CAJA</th><th>Fecha de inicio</th><th>D1</th><th>D2</th><th>D3</th><th>D4</th><th>D5</th><th>D6</th><th>D7</th><tbody><tr><td>Caja1</td><td>2017-07-31</td><td>10</td><td>1000</td><td>14</td><td>2</td><td>0</td><td>976</td><td>203</td></tr><tr><td>Caja2</td><td>2017-08-01</td><td>4</td><td>865</td><td>789</td><td>21</td><td>22</td><td>5</td></tr></tbody></table>
  ";*/

  return $datos;

 }

 public static function filterM($dato){
   $vehiculos= Vehiculo::mostrar();
   $marca = array();
   foreach($vehiculos as $value)
   { 
     if(strcasecmp($value->modelo,$dato) == 0){
       array_push($marca,$value);
     }
   }
   return $marca;

 }
 public static function modificar($datos, $img){
  // var_dump($datos);
  // var_dump($img);
  $vehiculos = Vehiculo::mostrar();

  $var=false;

  foreach( $vehiculos as $vehiculo ){
      if(strcasecmp($vehiculo->patente, $datos['patente']) == 0){
          //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y HUBICACION
          $origen = $img->file;
          $nombreOriginal =$img->getClientFilename();
          $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
        //  $destinoFoto = "./imagenes/".$datos['patente'].".".$ext;
          $destinoFoto=$vehiculo->foto;
          if(file_exists($destinoFoto)){
              copy($destinoFoto,"./backup/".$vehiculo->patente."_".date("dmy_His").".".$ext);
          }
          move_uploaded_file($origen, $destinoFoto);
          // MODIFICAR DATOS
          $vehiculo->foto=$destinoFoto;
          $vehiculo->marca = $datos['marca'];
          $vehiculo->modelo = $datos['modelo'];
          $vehiculo->precio = $datos['precio'];
          $var=true;
          break;
      }
  }
  if($var==true)
  {
    AlumDao::guardarTodos('./archivos/vehiculos.txt', $vehiculos);
  }
}
 
}
?>