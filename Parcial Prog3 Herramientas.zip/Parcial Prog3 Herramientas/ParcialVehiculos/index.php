<?PHP
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
require './vendor/autoload.php';
require_once './Vehiculo.php';
require_once './Turno.php';
require_once './Servicio.php';
$config['displayErrorDetails']=true;
$config['addContentLengthheader']=false;
$config['db']['host']   = 'localhost';
$config['db']['user']   = 'user';
$config['db']['pass']   = 'password';
$config['db']['dbname'] = 'exampleapp';
$app = new \Slim\App(["settings" => $config]);

$app->group('/vehiculos', function ()
{  
    $this->post('/cargarVehiculo', function ($request,$response,$args){
     $datos= $request->getParsedBody(); 
     $img = $request->getUploadedFiles();
     $vehiculo= new Vehiculo($datos['marca'],$datos['modelo'],$datos['patente'],$datos['precio'],$img["foto"]);
     Vehiculo::Guardar($vehiculo);
     echo"{mensaje:Se guardo con exito}";
    });

   $this->get('/consultarVehiculo', function($request,$response,$args){
    $new = $response->withJson(Vehiculo::mostrar());
            return $new;     
    });

    $this->get('/consultarVehiculoPor', function($request,$response,$args){
     // $modelo="modelo";
    $datos=$request->getQueryParams();
   // var_dump($datos["modelo"]);
    if(isset($datos["modelo"]))
    { 
      $retorno =  $response->withJson(Vehiculo::filterM($datos["modelo"]));
      return $retorno;  
    }
    else if(isset($datos["marca"]))
    {
      echo "Marca";
    }
    else if(isset($datos["patente"]))
    {
      echo "Patente";
    }
    else
    {
      echo "no se ingreso ningun argumento para realizar la busqueda";
    }
    });
    $this->post('/foto', function($request,$response,$args){
      $img = $request->getUploadedFiles(); 
      $datos= $request->getParsedBody();
      Vehiculo::modificar($datos,$img['foto']); 
         
  
      //AlumDao::moverImagen();

      });
      $this->get('/tabla', function($request,$response,$args){
       
        $response->getBody()->write(Vehiculo::mostarTablaVe());
        //echo "Tu dirección IP es: {$_SERVER['REMOTE_ADDR']}";
        return $response;
  
        //AlumDao::moverImagen();
  
        });
    
});
      /* $app->get('/consultarVehiculo', function (Request $request, Response $response, array $args) {
            $response->getBody()->write("Hello Word");
            return $response;
        /*  $new = $response->whithJason(Vehiculo::mostrar());
          return $new; 
             });*/

$app->run();

?>