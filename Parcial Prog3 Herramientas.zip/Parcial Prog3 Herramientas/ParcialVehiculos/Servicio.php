<?PHP
class Servicio
{
 public $id;
 public $tipo;
 public $precio;
 public $demora;
 
 
 public function __construct($id,$tip,$pre,$dem)
 {
     $this->id=$id;
     $this->tipo=$tip;
     $this->demora=$dem;
     $this->precio=$pre;
 }
 public function Json()
 {
     return json_encode($this);
 }
 
 
}
?>