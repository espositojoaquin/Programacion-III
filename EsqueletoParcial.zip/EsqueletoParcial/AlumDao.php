<?php
class AlumDao
{   
 
   
    public static function GuardarRegistro($path,$dato)
    { 
       if(file_exists($path))
       {
           $archivo=fopen($path,'a');
                       
           fwrite($archivo,json_encode($dato).PHP_EOL);  
        
           fclose($archivo);
       }
       else
       {
           echo "No exixte el archivo especificado";
       }             
                
    }
    public static function GuardarLista($path,$lista)
    {
       $archivo=fopen($path,'w');
       foreach ( $lista as $variable) {
        fwrite($archivo,json_encode($variable).PHP_EOL);  
       }
       fclose($archivo);
    }

   /* public static function moverImagen(){
        $origen=$_FILES["foto"]["tmp_name"];
        $exten= pathinfo($_FILES["foto"]["name"],PATHINFO_EXTENSION);
        $destino='Clases/imagenes/'.$_POST["legajo"].'.'.$exten;
        move_uploaded_file($origen,$destino);
        } 
*/     
 /*  public static function moverImagen(){
    $origen=$_FILES["foto"]["tmp_name"];
    $exten= pathinfo($_FILES["foto"]["name"],PATHINFO_EXTENSION);
    $destino='./archivos/usuarios.txt'.'_'.date('dmy').'.'.$exten;
    if(file_exists($destino))
    {
       copy($destino,'./backup/'.$_POST["patente"].'_'.date('dmy').'.'.$exten);
    }
     move_uploaded_file($origen,$destino);
    }*/ 
    public static function moverImagenes($img,$img2,$objeto){
      $origen = $img->file;
      $origen2 = $img2->file;
      $nombreOriginal = $img->getClientFilename();
      $nombreOriginal2 = $img2->getClientFilename();
      $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
      $ext2= pathinfo($nombreOriginal2, PATHINFO_EXTENSION);
      $destinoFoto = "./imagenes/pizzas/".$objeto->id."."."_"."1".".".$ext;
      $destinoFoto2 = "./imagenes/pizzas/".$objeto->id."."."_"."2".".".$ext;
      move_uploaded_file($origen, $destinoFoto);
      move_uploaded_file($origen2, $destinoFoto2);
      $objeto->foto=$destinoFoto;
      $objeto->foto2=$destinoFoto2;
      }

      public static function ModificarImagenes($img,$img2,$objeto)
      {
        $origen = $img->file;
        $origen2 = $img2->file;
        $nombreOriginal = $img->getClientFilename();
        $nombreOriginal2 = $img2->getClientFilename();
        $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
        $ext2= pathinfo($nombreOriginal2, PATHINFO_EXTENSION);
        $destinoFoto=$objeto->foto;
        $destinoFoto2=$objeto->foto2;
        if(file_exists($destinoFoto)){
            copy($destinoFoto,"./img/backup/".$objeto->legajo."_".date("dmy_His")."."."1".".".$ext);
        }
        if(file_exists($destinoFoto2)){
          copy($destinoFoto2,"./img/backup/".$objeto->legajo."_".date("dmy_His")."."."2".".".$ext2);
        }
        move_uploaded_file($origen, $destinoFoto);
        move_uploaded_file($origen2, $destinoFoto2);
        $objeto->foto=$destinoFoto;
        $objeto->foto2=$destinoFoto2;


        // MODIFICAR DATOS
      }


    public static function guardarTodos($path, $lista){
        $archivo = fopen($path, 'w');
        foreach($lista as $item){
            fwrite($archivo, $item->toJSON() . PHP_EOL);
        }
        fclose($archivo);
    }
      
    public static function LeerArchivo($path)
    {   if(file_exists($path))
         {
           $array=array();
           $path=fopen($path,'r');
            do{ 
                   
              $archivo= trim(fgets($path));
              if($archivo!='')
              array_push($array,json_decode($archivo));
            
              }while(!feof($path));
              fclose($path); 
             }
            else
            {
              echo "Archivo inexistente";
            }
          return $array;
        }

}


?>