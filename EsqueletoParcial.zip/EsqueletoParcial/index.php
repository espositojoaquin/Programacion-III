<?PHP
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
require './vendor/autoload.php';
require_once './Pizza.php';
$config['displayErrorDetails']=true;
$config['addContentLengthheader']=false;
$app = new \Slim\App(["settings" => $config]);
$app->group('/pizzas', function ()
{  
    $this->post('/cargarPizza', function ($request,$response,$args){
       
        $datos= $request->getParsedBody(); 
        $img = $request->getUploadedFiles();
        $pizza = new Pizza($datos['tipo'],$datos['cantidad'],$datos['sabor'],$datos['precio'],$img["foto"],$img['foto2']);
        echo Pizza::Guardar($pizza);
       });
       
       $this-get('/pizza',function($request,$response,$args){
        $datos=$request->getQueryParams();
        $retorno="{mensaje:Faltan campos}";
        if(isset($datos['sabor']) && isset($datos['tipo']))
        { 
          $retorno =  $response->withJson(Pizzas::filterTipoSabor($datos['tipo'],$datos['sabor']));
        }
       });

});
$app->run();