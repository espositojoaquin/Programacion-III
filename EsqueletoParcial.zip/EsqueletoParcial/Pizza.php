<?PHP
require_once './AlumDao.php';
class Pizza
{
 public $id;    
 public $tipo;
 public $cantidad;
 public $sabor;
 public $precio;
 public $foto;
 public $foto2;

 public function __construct($tip,$cant,$sab,$pre,$fot,$fot2)
 {   
     $this->tipo = $tip;
     $this->cantidad=$cant;
     $this->sabor=$sab;
     $this->precio=$pre;
     $this->foto=$fot;
     $this->foto2=$fot2;
    
 }
 public static function validarTipo($tipo)
 {  
    if(strcasecmp($tipo,"molde") == 0 || strcasecmp($tipo,"piedra") == 0){
      return true;
    }else
    {
        return false;
    }
 } 
 public static function validarSabor($sabor)
 {  
    if(strcasecmp($sabor,"muzza") == 0 || strcasecmp($sabor,"jamon") == 0 ||strcasecmp($sabor,"especial") == 0){
      return true;
    }else
    {
        return false;
    }
 }  
 
 public static function validarTipoSabor($sabor,$tipo)
 {  
     $datos = Pizza::mostrar();
     $var=false;
     foreach( $datos as $pizza){
        if(strcasecmp($pizza->sabor, $sabor) == 0 && strcasecmp($pizza->tipo, $tipo) == 0){
            //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y HUBICACION
          $var = true;
            break;
        }
    }
    return $var;
 }  
 
 public static function mostrar(){
    $datos = AlumDao::LeerArchivo("./archivos/pizza.txt");
    $pi = array();
    foreach ($datos as $key => $value) {
     array_push($pi,new Pizza($value->tipo,$value->cantidad,$value->sabor,$value->precio,$value->foto,$value->foto2));
    } 
    return $pi;
}

 public static function idAuto($objeto){
  $datos = Pizza::mostrar();
  $objeto->id=count($datos)+1;
 }

 public static function Guardar($objeto)
 { 
  if(Pizza:: validarTipoSabor($objeto->sabor,$objeto->tipo)==false)
  {   if(Pizza::validarSabor($objeto->sabor) && Pizza::validarTipo($objeto->tipo)){
      Pizza::idAuto($objeto);
      AlumDao::moverImagenes($objeto->foto,$objeto->foto2,$objeto);
      AlumDao::GuardarRegistro("./archivos/pizza.txt",$objeto);
      return "{mensaje:Se guardo con exito}";

      }
      else
      {
          return "{mensaje:sabor o tipo invalido}";
      }
  }
  else
  {
      return "{mensaje: La combinacion ya existe}";
  }
 }

public static function filterTipoSabor($tipo,$sabor){
  $datos = Pizza::mostrar();
   // $piz=array();
   $piz="";
   $sabor=false;
   $tipo=false;
    foreach( $datos as $pizza){
       if(strcasecmp($pizza->sabor, $sabor) == 0 && strcasecmp($pizza->tipo, $tipo) == 0){
         $piz=$pizza->cantidad;
           break;
       }
       if(strcasecmp($pizza->sabor, $sabor) == 0)
       {
           $sabor=true;
       }
       if(strcasecmp($pizza->tipo, $tipo) == 0){
           $tipo=true;
       }
   } 

   if($sabor==false)
   {
       $piz= "{mensaje: el sabor no existe}";
   }
   if($tipo==false){
    "{mensaje: El tipo no existe}";
   }
   return $piz; 
}

}
 ?>