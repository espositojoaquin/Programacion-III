$("document").ready(function () {
  //  $('#productos').hide();
    $("#Repuestos").click(prueba);

});

function prueba()
{   
    $('#productos').fadeIn(1000);
    document.getElementById('productos').hidden = false;
}
